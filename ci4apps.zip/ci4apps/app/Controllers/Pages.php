<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'STMIK Widya Pratama'
        ];
        echo view('pages/home', $data);
    }
    public function about()
    {
        $data = [
            'title' => 'About Me'
        ];
        echo view('pages/about', $data);
    }
    public function contact()
    {
        $data = [
            'title' => 'contact',
            'alamat' => [
                [
                    'type' => 'rumah',
                    'alamat' => 'kebulen pekalongan',
                    'hp' => '123'
                ],
                [
                    'type' => 'kantor',
                    'alamat' => 'jl patriot no 25 pekalongan',
                    'hp' => '456'
                ]

            ]

        ];
        echo view('pages/contact', $data);
    }
}
