<?php
namespace App\Controllers;
class Penjualan extends BaseController
{
    public function index()
    {
        session();
        $penjualanmodel = new \App\Models\PenjualanModel();
        $penjualan=$penjualanmodel->findAll();
        $data=[
            'penjualan'=>$penjualan,
            'validation'=> \Config\Services::validation()
        ];
        return view('lihat',$data);
    }

    public function simpan()
    {
        $penjualanmodel = new \App\Models\PenjualanModel();
        $penjualan=$penjualanmodel->findAll();
        if(!$this->validate([
            'tanggal'=>[
                'rules'=>'required|is_unique[$penjualan.tanggal]',
                'errors'=>[
                'required'=>'tanggal harus disi',
                'is_unique'=>'data sudah ada'
                ]
            ]
            ]
        )){
            $validation=\Config\Services::validation();
            return redirect()->to('/penjualan')->withInput()->with('validation',$validation);
        }

        $penjualanmodel = new \App\Models\PenjualanModel();
        $data=[
            'tanggal'=>$this->request->getVar('tanggal'),
            'jumlah'=>$this->request->getVar('jumlah')
        ];
        $penjualanmodel->insert($data);
        return redirect()->to('/penjualan');
    }
}
