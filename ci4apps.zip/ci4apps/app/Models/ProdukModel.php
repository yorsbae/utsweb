<?php

namespace App\Models;

use CodeIgniter\Model;

class ProdukModel extends Model
{
    protected $table = 'produk';
    protected $primarykey = 'kode';
    protected $allowedFields = ['kode', 'nama', 'harga', 'deskripsi', 'gambar'];
}
