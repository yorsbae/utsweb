<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<div class="container">
<div class="row">
<div class="col-sm-5">
<form method="post" action="/penjualan/simpan">
  <div class="row mb-3">
    <label for="tanggal" class="col-sm-2 col-form-label">Tanggal</label>
    <div class="col-sm-10">
      <input type="date" class="form-control <?= ($validation->hasError('tanggal')) ? 'is-invalid':'' ?>" id="tanggal" name="tanggal">
      <div class="invalid-feedback">
<?= $validation->getError('tanggal'); ?>

      </div>
    </div>
  </div>
  <div class="row mb-3">
    <label for="jumlah" class="col-sm-2 col-form-label">Jumlah</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" id="jumlah" name="jumlah" min="0" value="<?=old('jumlah'); ?>" >
    </div>
  </div>
    
  <button type="submit" class="btn btn-primary">Simpan</button>
</form>

</div>


<div class="col-sm-5">
<table class="table">
  <thead>
    <tr>
      <th scope="col">Tanggal</th>
      <th scope="col">Jumlah</th>
      </tr>
  </thead>
  <tbody>
      <?php $jumlah=0;foreach($penjualan as $p): ?>
    <tr>
      <td><?= $p['tanggal'] ?></td>
      <td><?= $p['jumlah'] ?></td>
      <?php $jumlah=$jumlah+$p['jumlah']; ?>
    </tr>
    <?php endforeach; ?>
    <tr>
      <th>jumlah</th>
      <td><?= $jumlah ?></td>
    </tr>


    </tbody>
</table>
</div>
</div>
</div>