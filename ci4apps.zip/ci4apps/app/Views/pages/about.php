<?= $this->extend('layout/template') ?>
<?= $this->section('content') ?>

<div class="container">
    <div class="row">
        <div class="col">
            <h1>DATA DIRI</h1>
            <p>NIM : 21.240.2100</p>
            <p>NAMA : Muhammad Arsya Ar-Rafif
            </p>
            <p>Alamat : Pekalongan</p>


        </div>
    </div>

</div>
<?= $this->endSection();
